#!/bin/bash

sudo python lab5.py
